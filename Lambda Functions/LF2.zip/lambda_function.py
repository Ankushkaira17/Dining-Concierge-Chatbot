import json
import boto3
import ast
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import os


def getDynamoDbData(table, requestData, businessIds):
    #print (requestData)
    
  
    if len(businessIds) <= 0:
        return 'We can not find any restaurant under this description, please try again.'

    textString = "Hello! Here are my " + requestData['cuisine'] + " restaurant suggestions for " + requestData['party'] +" people, for " + requestData['date'] + " at " + requestData['time'] + ". "
    count = 1

    for business in businessIds:
        responseData = table.query(KeyConditionExpression=Key('id').eq(business))

        if (responseData and len(responseData['Items']) >= 1 and responseData['Items'][0]['info']):
            responseData = responseData['Items'][0]['info']
            display_address = ', '.join(responseData['display_address'])

            textString = textString + " " + str(count) + "." + responseData['name'] + ", located at " + display_address + " "
            count += 1

    textString = textString + ". Enjoy your meal!"
    print (textString)
    return textString
    
def sendTextToUser(requestData,resultData):
    RECIPIENT = requestData['phone']

    print("RECIPIENT", RECIPIENT)
    print("resultData", resultData)
     # Create an SNS client
    sns = boto3.client(
         "sns",
         region_name="us-east-1"
    )
     # Send your sms message.
    try:
        response = sns.publish(
            PhoneNumber = RECIPIENT,
            Message = resultData
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("text message sent")
        print(response['MessageId'])
        return

def sendMailToUser(requestData, resultData):
    print(requestData)
    SENDER = "rahulgarg0697@gmail.com"
    RECIPIENT = requestData['email']
    AWS_REGION = "us-east-1"

    SUBJECT = "Your Dining recommendations"

    BODY_TEXT = ("AWS project in (Python)")

    # The HTML body of the email.
    BODY_HTML = """<html>
    <head></head>
    <body>
      <h1>Restaurant Suggestions</h1>
      <p>""" + resultData + """</p>
    </body>
    </html>
                """

    # The character encoding for the email.
    CHARSET = "UTF-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses',region_name=AWS_REGION)

    # return true
    # Try to send the email.
    try:
        #Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    # 'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
            # # If you are not using a configuration set, comment or delete the
            # # following line
            # ConfigurationSetName=CONFIGURATION_SET,
        )
    # Display an error if something goes wrong.
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])
        return


def lambda_handler(event, context):
    #sendTextToUser()
    print ("inside lambda handler")
    sqs = boto3.client('sqs')
    queue_url = 'https://sqs.us-east-1.amazonaws.com/524462994473/restaurants'
    
    # Receive message from SQS queue
    response = sqs.receive_message(
        QueueUrl=queue_url,
        AttributeNames=[
            'SentTimestamp'
        ],
        MaxNumberOfMessages=1,
        MessageAttributeNames=[
            'All'
        ],
        VisibilityTimeout=0,
        WaitTimeSeconds=15
    )
    print("before response")
    print(response)
    
    if (response and 'Messages' in response):

        # restaurant original host

        
        host = 'search-yelp-restaurants-pi5uu6x2lzpdmtdrtbchj4wkju.us-east-1.es.amazonaws.com'

        region = 'us-east-1'
        service = 'es'
        credentials = boto3.Session(aws_access_key_id = os.environ.get('AWS_ACCESS_KEY_ID'), aws_secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY')).get_credentials()
        awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
        es = Elasticsearch(
            hosts = [{'host': host, 'port': 443}],
            http_auth = awsauth,
            use_ssl = True,
            verify_certs = True,
            connection_class = RequestsHttpConnection
        )

        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('yelp-restaurants')

        for each_message in response['Messages']:
            message = each_message
            receipt_handle = message['ReceiptHandle']
            req_attributes = message['MessageAttributes']
            print(req_attributes)
            messageBody = message['Body']
            messageBody = ast.literal_eval(messageBody)
            res_category = messageBody['cuisine']
            print(res_category)
            searchData = es.search(index="restaurants", body={
                                                                "query": {
                                                                    "function_score": {
                                                                    "query": {
                                                                                "match": {"categories.title": res_category}
                                                                    },
                                                                    "boost": "5",
                                                                    "random_score": {},
                                                                    "boost_mode": "multiply"
                                                                    }
                                                                }
                                                                })
            sqs.delete_message(
                QueueUrl=queue_url,
                ReceiptHandle=receipt_handle
            )

            print(searchData)
            businessIds = []
            for hit in searchData['hits']['hits']:
                #print (hit)
                businessIds.append(hit['_source']['id'])

            # Call the dynamoDB
            resultData = getDynamoDbData(table, messageBody, businessIds)
            print (resultData)
            #print ('req_attributes----', req_attributes)
            # send the email
            sendMailToUser(messageBody, resultData)
            # send the text message
            sendTextToUser(messageBody,resultData)
            # Delete received message from queue
            
